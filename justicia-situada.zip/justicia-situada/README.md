# Justicia situada y pensamiento interseccional crítico desde el Sur Global

Este repositorio reúne el trabajo teórico, jurídico y epistémico orientado a subvertir el orden ontoepistémico colonial moderno desde una perspectiva de justicia situada e interseccional.

## Objetivo
Proponer un marco crítico que permita el reconocimiento y la protección de formas de violencia no nombradas por el derecho hegemónico, particularmente la **violencia interseccional**, el **LGBTcidio** y las formas de opresión estructural que afectan a personas racializadas, disidentes sexuales y comunidades originarias.

## Contenidos
- Marco teórico conceptual
- Glosario interseccional
- Propuesta de reforma legal
- Enlaces de acceso abierto

> 🌐 Consulta la publicación original en Zenodo:  
https://zenodo.org/record/[AQUÍ_TU_ID]

---

## ✊🏽 Categorías clave
- Episteme interseccional
- Justicia situada
- Interseccionalidad negativa, positiva e híbrida
- Violencia de género interseccional
- Discriminación estructural compuesta
- Extractivismo epistémico

---
