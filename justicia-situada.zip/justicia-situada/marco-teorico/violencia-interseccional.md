# Violencia Interseccional

La violencia interseccional no es una suma de violencias, sino una forma compleja de opresión estructural que emerge del entrelazamiento de sistemas como el racismo, el clasismo, el sexismo, la homofobia y la transfobia.

## Características
- Es estructural, no episódica.
- Es relacional y dinámica.
- Tiene consecuencias epistémicas, jurídicas y existenciales.

## Propuesta jurídica
Incorporar esta categoría en la Ley de Acceso de las Mujeres a una Vida Libre de Violencia, tanto en su versión estatal (Estado de México) como en la Ley General.

Más en: [exposición de motivos](../propuesta-legal/exposicion-de-motivos.md)
